package online.n22.hedq.bean;

import java.io.Serializable;
import java.util.List;

public class UserBean implements Serializable {

    /**
     * data : {"ds":"1","table1":[{"id":"4","Storefrontid":"2","username":"赵虎","password":"E10ADC3949BA59ABBE56E057F20F883E","state":"1","type":"2","b1":"","b2":"","b3":"","b4":"","b5":""}]}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean implements Serializable{
        /**
         * ds : 1
         * table1 : [{"id":"4","Storefrontid":"2","username":"赵虎","password":"E10ADC3949BA59ABBE56E057F20F883E","state":"1","type":"2","b1":"","b2":"","b3":"","b4":"","b5":""}]
         */

        private String ds;
        private List<Table1Bean> table1;

        public String getDs() {
            return ds;
        }

        public void setDs(String ds) {
            this.ds = ds;
        }

        public List<Table1Bean> getTable1() {
            return table1;
        }

        public void setTable1(List<Table1Bean> table1) {
            this.table1 = table1;
        }

        public static class Table1Bean implements Serializable{
            /**
             * id : 4
             * Storefrontid : 2
             * username : 赵虎
             * password : E10ADC3949BA59ABBE56E057F20F883E
             * state : 1
             * type : 2
             * b1 :
             * b2 :
             * b3 :
             * b4 :
             * b5 :
             */

            private String id;
            private String Storefrontid;
            private String username;
            private String password;
            private String state;
            private String type;
            private String b1;
            private String b2;
            private String b3;
            private String b4;
            private String b5;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getStorefrontid() {
                return Storefrontid;
            }

            public void setStorefrontid(String Storefrontid) {
                this.Storefrontid = Storefrontid;
            }

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }

            public String getPassword() {
                return password;
            }

            public void setPassword(String password) {
                this.password = password;
            }

            public String getState() {
                return state;
            }

            public void setState(String state) {
                this.state = state;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getB1() {
                return b1;
            }

            public void setB1(String b1) {
                this.b1 = b1;
            }

            public String getB2() {
                return b2;
            }

            public void setB2(String b2) {
                this.b2 = b2;
            }

            public String getB3() {
                return b3;
            }

            public void setB3(String b3) {
                this.b3 = b3;
            }

            public String getB4() {
                return b4;
            }

            public void setB4(String b4) {
                this.b4 = b4;
            }

            public String getB5() {
                return b5;
            }

            public void setB5(String b5) {
                this.b5 = b5;
            }
        }
    }
}
