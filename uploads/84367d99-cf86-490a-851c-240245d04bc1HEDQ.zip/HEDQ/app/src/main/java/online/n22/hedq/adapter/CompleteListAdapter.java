package online.n22.hedq.adapter;

import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

import online.n22.hedq.R;
import online.n22.hedq.bean.CompleteBean;

/**
 *
 */
public class CompleteListAdapter extends BaseQuickAdapter<CompleteBean.DataBean.Table1Bean, BaseViewHolder> {

    public CompleteListAdapter(int layoutResId, @Nullable List<CompleteBean.DataBean.Table1Bean> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, CompleteBean.DataBean.Table1Bean item) {
        TextView tv_orderId = helper.getView(R.id.tv_orderId);
        tv_orderId.setSelected(true);
        tv_orderId.setText(item.getNumber());

        TextView tv_creatDate = helper.getView(R.id.tv_creatDate);
        tv_creatDate.setSelected(true);
        tv_creatDate.setVisibility(View.GONE);
//        tv_creatDate.setText(item.getCreatDate());

        TextView tv_customerName = helper.getView(R.id.tv_customerName);
        tv_customerName.setSelected(true);
        tv_customerName.setText(item.getCustomer());

        TextView tv_phoneNumber = helper.getView(R.id.tv_phoneNumber);
        tv_phoneNumber.setSelected(true);
        tv_phoneNumber.setText(item.getPhone());

        TextView tv_projectType = helper.getView(R.id.tv_projectType);
        tv_projectType.setSelected(true);
        tv_projectType.setText(item.getProduct());


        TextView tv_address = helper.getView(R.id.tv_address);
        tv_address.setSelected(true);
        tv_address.setText(item.getAddress());


        TextView tv_completionTime = helper.getView(R.id.tv_completionTime);
        tv_completionTime.setSelected(true);
        tv_completionTime.setText(item.getCfmtime_install());
    }
}