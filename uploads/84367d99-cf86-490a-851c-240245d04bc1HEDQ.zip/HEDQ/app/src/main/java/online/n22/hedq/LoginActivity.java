package online.n22.hedq;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.Utils;
import com.google.gson.Gson;

import org.w3c.dom.Text;

import java.util.List;

import online.n22.hedq.bean.UserBean;
import online.n22.hedq.update.UpdateManager;
import online.n22.hedq.utils.Api;
import online.n22.hedq.utils.DialogHelp;
import online.n22.hedq.utils.XConfigUtil;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

/**
 *
 */
public class LoginActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks {

    private EditText et_username;
    private EditText et_password;
    private TextView tv_version;
    private Button btn_login;

    String username;
    String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        et_username = (EditText) findViewById(R.id.et_username);
        et_password = (EditText) findViewById(R.id.et_password);
        tv_version = (TextView) findViewById(R.id.tv_version);
        btn_login = (Button) findViewById(R.id.btn_login);
        String json = XConfigUtil.getInstance(LoginActivity.this).getString("LOGIN_INFO");
        initTask();
        if (!TextUtils.isEmpty(json)) {
            UserBean userBean = new Gson().fromJson(json, UserBean.class);
            String username = userBean.getData().getTable1().get(0).getUsername();
            et_username.setText(username);
        }
        Utils.init(this);
        tv_version.setText("版本号 ："+AppUtils.getAppVersionName());
        btn_login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                username = et_username.getText().toString().trim();
                password = et_password.getText().toString().trim();
                if (!TextUtils.isEmpty(username) && !TextUtils.isEmpty(password)) {
                    Api.getPhlogin(LoginActivity.this, username, password, new Api.OnResponseListener() {
                        @Override
                        public void onResponse(String json) {
                            XConfigUtil.getInstance(LoginActivity.this).putString("LOGIN_INFO", json);
                            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                            finish();
                        }
                    });
                } else {
                    DialogHelp.getMessageDialog(LoginActivity.this, "请输入登录用户名/密码!").show();
                }
            }
        });
    }

    private void init() {
        isStart = true;
        new UpdateManager(LoginActivity.this, true).checkUpdate();
    }

    private static final int WR_PERM = 1;
    boolean isStart = false;

    @AfterPermissionGranted(WR_PERM)
    private void initTask() {
        String[] perms = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
        if (EasyPermissions.hasPermissions(this, perms)) {
            if (!isStart) {
                init();
            }
        } else {
            // Request one permission
            EasyPermissions.requestPermissions(this, "请求获取文件存储权限",
                    WR_PERM, perms);
        }
    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        if (perms != null && perms.size() == 2) {
            if (!isStart) {
                init();
            }
        } else {
            displayFrameworkBugMessageAndExit();
        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        displayFrameworkBugMessageAndExit();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // EasyPermissions handles the request result.
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    private void displayFrameworkBugMessageAndExit() {
        Toast.makeText(this, "应用无法完成初始化,请正确授权。", Toast.LENGTH_LONG).show();
    }
}

