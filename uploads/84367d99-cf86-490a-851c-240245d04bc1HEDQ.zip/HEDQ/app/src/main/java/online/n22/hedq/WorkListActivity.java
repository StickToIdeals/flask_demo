package online.n22.hedq;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.KeyboardUtils;
import com.blankj.utilcode.util.ThreadPoolUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.animation.BaseAnimation;
import com.google.gson.Gson;
import com.n22.barcodescanner.zxing.activity.CaptureActivity;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import online.n22.hedq.adapter.WorkListAdapter;
import online.n22.hedq.bean.RespBean;
import online.n22.hedq.bean.UserBean;
import online.n22.hedq.bean.WorkBean;
import online.n22.hedq.utils.Api;
import online.n22.hedq.utils.Constants;
import online.n22.hedq.utils.DialogHelp;
import online.n22.hedq.utils.XConfigUtil;

public class WorkListActivity extends BaseActivity {
    private TextView tv_title;
    private ImageView iv_back;
    private ImageView iv_qr;
    private CheckBox rb_time;
    private CheckBox rb_name;
    private RecyclerView recyclerView;
    private ArrayList<WorkBean.DataBean.Table1Bean> mDataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_list);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText("工单列表");
        iv_back = (ImageView) findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WorkListActivity.this.finish();
            }
        });
        iv_qr = (ImageView) findViewById(R.id.iv_qr);
        iv_qr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WorkListActivity.this, CaptureActivity.class);
                startActivityForResult(intent, Constants.QRCODE_REQUEST_CODE);
            }
        });
        rb_time = (CheckBox) findViewById(R.id.rb_time);
        rb_name = (CheckBox) findViewById(R.id.rb_name);
        rb_time.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rb_time.setTextColor(Color.parseColor("#00A8DA"));
                } else {
                    rb_time.setTextColor(Color.parseColor("#98948F"));
                }
            }
        });
        rb_name.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rb_name.setTextColor(Color.parseColor("#00A8DA"));
                } else {
                    rb_name.setTextColor(Color.parseColor("#98948F"));
                }
            }
        });
        recyclerView = (RecyclerView) findViewById(R.id.rv_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        String json = XConfigUtil.getInstance(WorkListActivity.this).getString("LOGIN_INFO");
        if (!TextUtils.isEmpty(json)) {
            UserBean userBean = new Gson().fromJson(json, UserBean.class);
            String id = userBean.getData().getTable1().get(0).getId();

            Api.getPhprogram(WorkListActivity.this, id, new Api.OnResponseListener() {
                @Override
                public void onResponse(String json) {
                    WorkBean workBean = new Gson().fromJson(json, WorkBean.class);
                    mDataList = new ArrayList<>();
                    mDataList.addAll(workBean.getData().getTable1());
                    BaseQuickAdapter workListAdapter = new WorkListAdapter(R.layout.common_item_work_layout, mDataList);
                    workListAdapter.openLoadAnimation(new BaseAnimation() {
                        @Override
                        public Animator[] getAnimators(View view) {
                            return new Animator[]{
                                    ObjectAnimator.ofFloat(view, "scaleY", 1, 1.1f, 1),
                                    ObjectAnimator.ofFloat(view, "scaleX", 1, 1.1f, 1)
                            };
                        }
                    });
                    workListAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                            Intent intent = new Intent(WorkListActivity.this, DetailActivity.class);
                            intent.putExtra("key_item", mDataList.get(position));
                            intent.putExtra("index", "0");
                            startActivity(intent);
                        }
                    });
                    workListAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
                        @Override
                        public void onItemChildClick(BaseQuickAdapter adapter, View view, final int position) {
                            if (view.getId() == R.id.btn_appointment) {
                                Intent intent = new Intent(WorkListActivity.this, AppointmentActivity.class);
                                intent.putExtra("key_item", mDataList.get(position));
                                startActivity(intent);
                            } else if (view.getId() == R.id.btn_finished) {
                                DialogHelp.getConfirmDialog(WorkListActivity.this, "单据 " + mDataList.get(position).getNumber() + " 是否已完工，请确认！", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
                                        Api.getPhservice(WorkListActivity.this, mDataList.get(position).getId(), f.format(new Date()), new Api.OnResponseListener() {
                                            @Override
                                            public void onResponse(String json) {
                                                RespBean resp = new Gson().fromJson(json, RespBean.class);
                                                if ("1".equals(resp.getData().getDs())) {
                                                    DialogHelp.getMessageDialog(WorkListActivity.this, resp.getData().getValue()).show();
                                                }
                                            }
                                        });
                                    }
                                }).show();
                            }
                        }
                    });
                    recyclerView.setAdapter(workListAdapter);
                }
            });
        } else {
            DialogHelp.getMessageDialog(WorkListActivity.this, "程序未知错误，请重新登陆！").show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.QRCODE_REQUEST_CODE) {
            if (null != data) {
                if (resultCode == Activity.RESULT_OK) {
                    Toast.makeText(WorkListActivity.this, data.getStringExtra("result"), Toast.LENGTH_SHORT).show();
                }
            } else {

            }
        }
    }

}
