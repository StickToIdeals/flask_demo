package online.n22.hedq.adapter;

import android.support.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

import online.n22.hedq.R;
import online.n22.hedq.bean.HomeItem;

/**
 *
 */
public class HomeListAdapter extends BaseQuickAdapter<HomeItem, BaseViewHolder> {

    public HomeListAdapter(int layoutResId, @Nullable List<HomeItem> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, HomeItem item) {
        helper.setText(R.id.tv_edit_pass, item.getTitle());
        helper.setBackgroundRes(R.id.iv_icon, item.getResId());
    }
}
