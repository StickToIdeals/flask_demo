package online.n22.hedq;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.animation.BaseAnimation;
import com.google.gson.Gson;
import com.n22.barcodescanner.zxing.activity.CaptureActivity;

import java.util.ArrayList;

import online.n22.hedq.adapter.CompleteListAdapter;
import online.n22.hedq.bean.CompleteBean;
import online.n22.hedq.bean.UserBean;
import online.n22.hedq.utils.Api;
import online.n22.hedq.utils.Constants;
import online.n22.hedq.utils.DialogHelp;
import online.n22.hedq.utils.XConfigUtil;

public class CompleteListActivity extends BaseActivity {
    private TextView tv_title;
    private ImageView iv_back;
    private ImageView iv_qr;
    private CheckBox rb_time;
    private CheckBox rb_name;
    private RecyclerView recyclerView;
    private ArrayList<CompleteBean.DataBean.Table1Bean> mDataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_list);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText("已完成工单");
        iv_back = (ImageView) findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CompleteListActivity.this.finish();
            }
        });
        iv_qr = (ImageView) findViewById(R.id.iv_qr);
        iv_qr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CompleteListActivity.this, CaptureActivity.class);
                startActivityForResult(intent, Constants.QRCODE_REQUEST_CODE);
            }
        });
        rb_time = (CheckBox) findViewById(R.id.rb_time);
        rb_name = (CheckBox) findViewById(R.id.rb_name);
        rb_time.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rb_time.setTextColor(Color.parseColor("#00A8DA"));
                } else {
                    rb_time.setTextColor(Color.parseColor("#98948F"));
                }
            }
        });
        rb_name.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rb_name.setTextColor(Color.parseColor("#00A8DA"));
                } else {
                    rb_name.setTextColor(Color.parseColor("#98948F"));
                }
            }
        });
        recyclerView = (RecyclerView) findViewById(R.id.rv_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        String json = XConfigUtil.getInstance(CompleteListActivity.this).getString("LOGIN_INFO");
        if (!TextUtils.isEmpty(json)) {
            UserBean userBean = new Gson().fromJson(json, UserBean.class);
            String id = userBean.getData().getTable1().get(0).getId();
            Api.getPhlist(CompleteListActivity.this, id, new Api.OnResponseListener() {
                @Override
                public void onResponse(String json) {
                    CompleteBean completeBean = new Gson().fromJson(json, CompleteBean.class);
                    mDataList = new ArrayList<>();
                    mDataList.addAll(completeBean.getData().getTable1());
                    BaseQuickAdapter workListAdapter = new CompleteListAdapter(R.layout.common_item_complete_layout, mDataList);
                    workListAdapter.openLoadAnimation(new BaseAnimation() {
                        @Override
                        public Animator[] getAnimators(View view) {
                            return new Animator[]{
                                    ObjectAnimator.ofFloat(view, "scaleY", 1, 1.1f, 1),
                                    ObjectAnimator.ofFloat(view, "scaleX", 1, 1.1f, 1)
                            };
                        }
                    });
                    workListAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                            Intent intent = new Intent(CompleteListActivity.this, DetailActivity.class);
                            intent.putExtra("key_item", mDataList.get(position));
                            intent.putExtra("index", "1");
                            startActivity(intent);
                        }
                    });
                    recyclerView.setAdapter(workListAdapter);
                }
            });
        } else {
            DialogHelp.getMessageDialog(CompleteListActivity.this, "程序未知错误，请重新登陆！").show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.QRCODE_REQUEST_CODE) {
            if (null != data) {
                if (resultCode == Activity.RESULT_OK) {
                    Toast.makeText(CompleteListActivity.this, data.getStringExtra("result"), Toast.LENGTH_SHORT).show();
                }
            } else {

            }
        }
    }
}
