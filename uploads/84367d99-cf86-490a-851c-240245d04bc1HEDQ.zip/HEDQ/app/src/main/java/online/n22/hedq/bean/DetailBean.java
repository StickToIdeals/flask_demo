package online.n22.hedq.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class DetailBean implements Serializable {

    /**
     * id : 1
     * number : GDBH2018090214475555
     * Product_type : 空调
     * product : CJ系列1.5匹变频壁挂式空调
     * Product_typeid : 1
     * customer : 张三
     * phone : 15966666666
     * address : 某某市某某区某某街某某路XXX-XXX号 666
     * esttime_delivery : 2018/9/2 0:00:00
     * esttime_install : 2018/9/2 0:00:00
     * sectime_install : 2018/1/1 0:00:00
     * cfmtime_install :
     * staff : 张龙
     * vehicle : 赵虎
     * state : 2
     * remarks :
     * table1 : [{"高空作业":"10.0000","铜管加长":"20.0000","外机支架":"30.0000","外墙打孔":"40.0000"}]
     */

    private String id;
    private String number;
    private String Product_type;
    private String product;
    private String Product_typeid;
    private String customer;
    private String phone;
    private String address;
    private String esttime_delivery;
    private String esttime_install;
    private String sectime_install;
    private String cfmtime_install;
    private String staff;
    private String vehicle;
    private String state;
    private String remarks;
    private List<Table1Bean> table1;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getProduct_type() {
        return Product_type;
    }

    public void setProduct_type(String Product_type) {
        this.Product_type = Product_type;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProduct_typeid() {
        return Product_typeid;
    }

    public void setProduct_typeid(String Product_typeid) {
        this.Product_typeid = Product_typeid;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEsttime_delivery() {
        return esttime_delivery;
    }

    public void setEsttime_delivery(String esttime_delivery) {
        this.esttime_delivery = esttime_delivery;
    }

    public String getEsttime_install() {
        return esttime_install;
    }

    public void setEsttime_install(String esttime_install) {
        this.esttime_install = esttime_install;
    }

    public String getSectime_install() {
        return sectime_install;
    }

    public void setSectime_install(String sectime_install) {
        this.sectime_install = sectime_install;
    }

    public String getCfmtime_install() {
        return cfmtime_install;
    }

    public void setCfmtime_install(String cfmtime_install) {
        this.cfmtime_install = cfmtime_install;
    }

    public String getStaff() {
        return staff;
    }

    public void setStaff(String staff) {
        this.staff = staff;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public List<Table1Bean> getTable1() {
        return table1;
    }

    public void setTable1(List<Table1Bean> table1) {
        this.table1 = table1;
    }

    public static class Table1Bean implements Serializable {
        /**
         * 高空作业 : 10.0000
         * 铜管加长 : 20.0000
         * 外机支架 : 30.0000
         * 外墙打孔 : 40.0000
         */

        @SerializedName("高空作业")
        private String gkzy;
        @SerializedName("铜管加长")
        private String tgjc;
        @SerializedName("外机支架")
        private String wjzj;
        @SerializedName("外墙打孔")
        private String wqdq;

        public String getGkzy() {
            return gkzy;
        }

        public void setGkzy(String gkzy) {
            this.gkzy = gkzy;
        }

        public String getTgjc() {
            return tgjc;
        }

        public void setTgjc(String tgjc) {
            this.tgjc = tgjc;
        }

        public String getWjzj() {
            return wjzj;
        }

        public void setWjzj(String wjzj) {
            this.wjzj = wjzj;
        }

        public String getWqdq() {
            return wqdq;
        }

        public void setWqdq(String wqdq) {
            this.wqdq = wqdq;
        }
    }
}
