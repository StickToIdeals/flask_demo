package online.n22.hedq;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ActivityUtils;
import com.google.gson.Gson;

import online.n22.hedq.bean.CompleteBean;
import online.n22.hedq.bean.DetailBean;
import online.n22.hedq.bean.WorkBean;
import online.n22.hedq.utils.Api;

public class DetailActivity extends BaseActivity {
    private TextView tv_title;
    private ImageView iv_back;

    private TextView tv_number;
    private TextView tv_product_type;
    private TextView tv_product;
    private TextView tv_customer;
    private TextView tv_phone;
    private TextView tv_address;
    private TextView tv_esttime_delivery;
    private TextView tv_esttime_install;
    private TextView tv_sectime_install;
    private TextView tv_cfmtime_install;
    private TextView tv_staff;
    private TextView tv_vehicle;
    private TextView tv_state;
    private TextView tv_remarks;
    private TextView tv_gkzy;
    private TextView tv_tgjc;
    private TextView tv_wjzj;
    private TextView tv_wqdk;

    private String index;
    private String id;
    private WorkBean.DataBean.Table1Bean table1Bean1;
    private CompleteBean.DataBean.Table1Bean table1Bean2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        index = getIntent().getStringExtra("index");
        if ("0".equals(index)) {
            table1Bean1 = (WorkBean.DataBean.Table1Bean) getIntent().getSerializableExtra("key_item");
            id = table1Bean1.getId();
        } else if ("1".equals(index)) {
            table1Bean2 = (CompleteBean.DataBean.Table1Bean) getIntent().getSerializableExtra("key_item");
            id = table1Bean2.getId();
        }
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText("单据详情 " + id);
        iv_back = (ImageView) findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        tv_number = (TextView) findViewById(R.id.tv_number);
        tv_product_type = (TextView) findViewById(R.id.tv_product_type);
        tv_product = (TextView) findViewById(R.id.tv_product);
        tv_customer = (TextView) findViewById(R.id.tv_customer);
        tv_phone = (TextView) findViewById(R.id.tv_phone);
        tv_address = (TextView) findViewById(R.id.tv_address);
        tv_esttime_delivery = (TextView) findViewById(R.id.tv_esttime_delivery);
        tv_esttime_install = (TextView) findViewById(R.id.tv_esttime_install);
        tv_sectime_install = (TextView) findViewById(R.id.tv_sectime_install);
        tv_cfmtime_install = (TextView) findViewById(R.id.tv_cfmtime_install);
        tv_staff = (TextView) findViewById(R.id.tv_staff);
        tv_vehicle = (TextView) findViewById(R.id.tv_vehicle);
        tv_state = (TextView) findViewById(R.id.tv_state);
        tv_remarks = (TextView) findViewById(R.id.tv_remarks);

        tv_gkzy = (TextView) findViewById(R.id.tv_gkzy);
        tv_tgjc = (TextView) findViewById(R.id.tv_tgjc);
        tv_wjzj = (TextView) findViewById(R.id.tv_wjzj);
        tv_wqdk = (TextView) findViewById(R.id.tv_wqdk);

        Api.getPhinfo(DetailActivity.this, id, new Api.OnResponseListener() {
            @Override
            public void onResponse(String json) {
                DetailBean detailBean = new Gson().fromJson(json, DetailBean.class);

                tv_number.setText(detailBean.getNumber());
                tv_product_type.setText(detailBean.getProduct_type());
                tv_product.setText(detailBean.getProduct());
                tv_customer.setText(detailBean.getCustomer());
                tv_phone.setText(detailBean.getPhone());
                tv_address.setText(detailBean.getAddress());
                tv_esttime_delivery.setText(detailBean.getEsttime_delivery());
                tv_esttime_install.setText(detailBean.getEsttime_install());
                tv_sectime_install.setText(detailBean.getSectime_install());
                tv_cfmtime_install.setText(detailBean.getCfmtime_install());
                tv_staff.setText(detailBean.getStaff());
                tv_vehicle.setText(detailBean.getVehicle());
                tv_state.setText(detailBean.getState());
                tv_remarks.setText(detailBean.getRemarks());
                try {
                    tv_gkzy.setText(detailBean.getTable1().get(0).getGkzy());
                    tv_tgjc.setText(detailBean.getTable1().get(0).getTgjc());
                    tv_wjzj.setText(detailBean.getTable1().get(0).getWjzj());
                    tv_wqdk.setText(detailBean.getTable1().get(0).getWqdq());
                } catch (Exception e) {
                }
            }
        });
    }


}
