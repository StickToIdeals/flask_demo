package online.n22.hedq.update;


import android.text.TextUtils;

import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import okhttp3.Call;
import online.n22.hedq.bean.AppBean;
import online.n22.hedq.bean.RespBean;
import online.n22.hedq.utils.DialogHelp;

/**
 * XRClient 网络交互类
 *
 * @author spoon
 * @version 1.0.0
 * @created at 2016/9/4
 */
public class UpdateApi {

    /**
     * 检验App版本
     *
     * @author spoon
     * @created at 2016/9/4
     * @version 1.0.0
     */
    public static void checkUpdate(final OnCheckUpdateListener listener) {
        OkHttpUtils.get().url("http://api.fir.im/apps/latest/5b94872cca87a80ba7128028?api_token=0ac334a22e69c2345a5cec8e1674fff9").build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        listener.onNoUpdateAvailable();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        AppBean appBean = new Gson().fromJson(json,AppBean.class);
                        listener.onUpdateAvailable(appBean);
                    }
                });
    }

    public interface OnCheckUpdateListener {
        void onNoUpdateAvailable();

        void onUpdateAvailable(AppBean appBean);
    }
}
