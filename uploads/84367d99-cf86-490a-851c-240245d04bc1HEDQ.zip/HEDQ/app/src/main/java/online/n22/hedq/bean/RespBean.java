package online.n22.hedq.bean;

public class RespBean {

    /**
     * data : {"ds":"0","value":"用户名或密码错误！"}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * ds : 0
         * value : 用户名或密码错误！
         */

        private String ds;
        private String value;

        public String getDs() {
            return ds;
        }

        public void setDs(String ds) {
            this.ds = ds;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
}
