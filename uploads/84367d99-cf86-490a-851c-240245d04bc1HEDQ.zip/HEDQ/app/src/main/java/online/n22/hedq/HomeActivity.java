package online.n22.hedq;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.animation.BaseAnimation;

import java.util.ArrayList;

import online.n22.hedq.adapter.HomeListAdapter;
import online.n22.hedq.bean.HomeItem;

public class HomeActivity extends BaseActivity {
    private TextView tv_title;
    private ImageView iv_back;
    private RecyclerView recyclerView;
    private ArrayList<HomeItem> mDataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText("功能列表");
        iv_back = (ImageView) findViewById(R.id.iv_back);
        iv_back.setVisibility(View.GONE);
        recyclerView = (RecyclerView) findViewById(R.id.rv_list);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        mDataList = new ArrayList<>();
        HomeItem item = new HomeItem("工单列表", R.mipmap.icon_no_complete);
        mDataList.add(item);
        item = new HomeItem("已完成工单", R.mipmap.icon_ok_complete);
        mDataList.add(item);
        item = new HomeItem("修改密码", R.mipmap.icon_edit_pass);
        mDataList.add(item);
        BaseQuickAdapter homeListAdapter = new HomeListAdapter(R.layout.home_item_layout, mDataList);
        homeListAdapter.openLoadAnimation(new BaseAnimation() {
            @Override
            public Animator[] getAnimators(View view) {
                return new Animator[]{
                        ObjectAnimator.ofFloat(view, "scaleY", 1, 1.1f, 1),
                        ObjectAnimator.ofFloat(view, "scaleX", 1, 1.1f, 1)
                };
            }
        });
        homeListAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                HomeItem homeItem = (HomeItem) adapter.getData().get(position);
                if ("工单列表".equals(homeItem.getTitle())) {
                    startActivity(new Intent(HomeActivity.this, WorkListActivity.class));
                } else if ("已完成工单".equals(homeItem.getTitle())) {
                    startActivity(new Intent(HomeActivity.this, CompleteListActivity.class));
                } else if ("协定安装时间".equals(homeItem.getTitle())) {
                    startActivity(new Intent(HomeActivity.this, AppointmentActivity.class));
                } else if ("修改密码".equals(homeItem.getTitle())) {
                    startActivity(new Intent(HomeActivity.this, EditPassActivity.class));
                }
            }
        });
        recyclerView.setAdapter(homeListAdapter);
    }

    // 用来计算返回键的点击间隔时间
    private long exitTime = 0;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK
                && event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((System.currentTimeMillis() - exitTime) > 2000) {
                //弹出提示，可以有多种方式
                Toast.makeText(getApplicationContext(), "再按一次退出程序", Toast.LENGTH_SHORT).show();
                exitTime = System.currentTimeMillis();
            } else {
                finish();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
