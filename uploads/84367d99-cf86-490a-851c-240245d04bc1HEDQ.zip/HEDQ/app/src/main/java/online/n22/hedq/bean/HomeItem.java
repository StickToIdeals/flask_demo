package online.n22.hedq.bean;

import java.io.Serializable;

public class HomeItem implements Serializable {
    private String title;
    private int resId;

    @Override
    public String toString() {
        return "HomeItem{" +
                "title='" + title + '\'' +
                ", resId=" + resId +
                '}';
    }

    public HomeItem() {
    }

    public HomeItem(String title, int resId) {
        this.title = title;
        this.resId = resId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }
}
