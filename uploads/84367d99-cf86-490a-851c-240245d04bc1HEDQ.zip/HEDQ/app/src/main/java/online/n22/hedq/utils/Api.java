package online.n22.hedq.utils;

import android.app.Activity;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.Call;
import online.n22.hedq.bean.RespBean;
import online.n22.hedq.bean.UserBean;

public class Api {

    public static final String base_url = "http://506130.nat123.net:19126/process.asmx/";

    /**
     * 登录
     *
     * @param activity
     * @param username
     * @param password
     * @param listener
     */
    public static void getPhlogin(final Activity activity, String username, String password, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phlogin")
                .addParams("username", username)
                .addParams("password", password).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
                                try {
                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
                                    if ("0".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
                                    } else {
                                        listener.onResponse(newJson);
                                    }
                                } catch (Exception e) {
                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * 修改密码
     *
     * @param activity
     * @param userid
     * @param oldpwd
     * @param newpwd
     * @param listener
     */
    public static void getPhres(final Activity activity, String userid, String oldpwd, String newpwd, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phres")
                .addParams("userid", userid)
                .addParams("oldpwd", oldpwd)
                .addParams("newpwd", newpwd).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
                                try {
                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
                                    if ("0".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
                                    } else {
                                        listener.onResponse(newJson);
                                    }
                                } catch (Exception e) {
                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * 查询列表
     *
     * @param activity
     * @param userid
     * @param listener
     */
    public static void getPhprogram(final Activity activity, String userid, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phprogram")
                .addParams("userid", userid).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
                                try {
                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
                                    if ("0".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
                                    } else {
                                        listener.onResponse(newJson);
                                    }
                                } catch (Exception e) {
                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * 查询已完成列表
     *
     * @param activity
     * @param userid
     * @param listener
     */
    public static void getPhlist(final Activity activity, String userid, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phlist")
                .addParams("userid", userid).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
                                try {
                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
                                    if ("0".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
                                    } else {
                                        listener.onResponse(newJson);
                                    }
                                } catch (Exception e) {
                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * 单据详细信息
     *
     * @param activity
     * @param billid
     * @param userid
     * @param listener
     */
    public static void getPhinfo(final Activity activity, String billid, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phinfo")
                .addParams("billid", billid).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
//                                try {
//                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
//                                    if ("0".equals(resp.getData().getDs())) {
//                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
//                                    } else {
                                        listener.onResponse(newJson);
//                                    }
//                                } catch (Exception e) {
//                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
//                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * 确认安装时间
     *
     * @param activity
     * @param billid
     * @param time
     * @param state
     * @param listener
     */
    public static void getPhtime(final Activity activity, String billid, String time, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phtime")
                .addParams("billid", billid)
                .addParams("time", time).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
                                try {
                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
                                    if ("0".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
                                    } else {
                                        listener.onResponse(newJson);
                                    }
                                } catch (Exception e) {
                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * 送货完成
     *
     * @param activity
     * @param billid
     * @param delivery
     * @param listener
     */
    public static void getPhservice(final Activity activity, String billid, String delivery, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phservice")
                .addParams("billid", billid)
                .addParams("delivery", delivery).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
                                try {
                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
                                    if ("0".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
                                    } else {
                                        listener.onResponse(newJson);
                                    }
                                } catch (Exception e) {
                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * @param activity
     * @param billid
     * @param delivery
     * @param listener
     */
    public static void getPhinstall(final Activity activity, String billid, String delivery, final OnResponseListener listener) {
        final KProgressHUD alertHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("请稍等...").show();
        OkHttpUtils.get().url(base_url + "phinstall")
                .addParams("billid", billid).build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int i) {
                        alertHUD.dismiss();
                        DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员!").show();
                    }

                    @Override
                    public void onResponse(String json, int i) {
                        alertHUD.dismiss();
                        String newJson = xmlToString(json);
                        newJson = htmlToString(newJson);
                        if (!TextUtils.isEmpty(newJson)) {
                            if (newJson.contains("<div class='container'>")) {//
                                DialogHelp.getMessageDialog(activity, newJson).show();
                            } else {
                                try {
                                    RespBean resp = new Gson().fromJson(newJson, RespBean.class);
                                    if ("0".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(activity, resp.getData().getValue()).show();
                                    } else {
                                        listener.onResponse(newJson);
                                    }
                                } catch (Exception e) {
                                    DialogHelp.getMessageDialog(activity, e.getMessage() + "请联系管理员！").show();
                                }
                            }
                        } else {
                            DialogHelp.getMessageDialog(activity, json + "请联系管理员!").show();
                        }
                    }
                });
    }

    /**
     * 回调成功数据
     */
    public interface OnResponseListener {
        void onResponse(String json);
    }

    /**
     * @作者 zxy
     * xml 格式转换成tostring形式
     * @创建日期 2018-08-29
     */
    public static String xmlToString(String string) {
        String str = string.replace("<string xmlns=\"http://tempuri.org/\">", "");
        str = str.replace("</string>", "");
        str = str.replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
        str = str.replace("\r\n", "");
        return str.trim();
    }

    public static String htmlToString(String string){
        if(string.contains("<!DOCTYPE html PUBLIC")){
            string = string.substring(string.indexOf("<body>")+6,string.indexOf("</body>"));
            string = string.replaceAll("\r\n","");
            string = string.replaceAll("\t","");
        }
        return string;
    }
}
