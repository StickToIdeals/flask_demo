package online.n22.hedq.utils;

public class Constants {
    public static final int QRCODE_REQUEST_CODE = 100;
}
