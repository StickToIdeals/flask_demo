package online.n22.hedq.bean;

import java.io.Serializable;
import java.util.List;

public class WorkBean implements Serializable {

    /**
     * data : {"ds":"1","table1":[{"id":"2","number":"GDBH201809031351252013","Product_type":"空调","product":"CJ系列1.5匹变频壁挂式空调","customer":"李刚","phone":"18623333333","address":"XXXXXXXXXXXXXXXXXX","esttime_delivery":"2018/9/3 0:00:00","esttime_install":"2018/9/3 0:00:00","sectime_delivery":"","sectime_install":"","cfmtime_delivery":"","cfmtime_install":"","staff":"赵虎","vehicle":"赵虎","state":"2"}]}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean implements Serializable{
        /**
         * ds : 1
         * table1 : [{"id":"2","number":"GDBH201809031351252013","Product_type":"空调","product":"CJ系列1.5匹变频壁挂式空调","customer":"李刚","phone":"18623333333","address":"XXXXXXXXXXXXXXXXXX","esttime_delivery":"2018/9/3 0:00:00","esttime_install":"2018/9/3 0:00:00","sectime_delivery":"","sectime_install":"","cfmtime_delivery":"","cfmtime_install":"","staff":"赵虎","vehicle":"赵虎","state":"2"}]
         */

        private String ds;
        private List<Table1Bean> table1;

        public String getDs() {
            return ds;
        }

        public void setDs(String ds) {
            this.ds = ds;
        }

        public List<Table1Bean> getTable1() {
            return table1;
        }

        public void setTable1(List<Table1Bean> table1) {
            this.table1 = table1;
        }

        public static class Table1Bean implements Serializable{
            /**
             * id : 2
             * number : GDBH201809031351252013
             * Product_type : 空调
             * product : CJ系列1.5匹变频壁挂式空调
             * customer : 李刚
             * phone : 18623333333
             * address : XXXXXXXXXXXXXXXXXX
             * esttime_delivery : 2018/9/3 0:00:00
             * esttime_install : 2018/9/3 0:00:00
             * sectime_delivery :
             * sectime_install :
             * cfmtime_delivery :
             * cfmtime_install :
             * staff : 赵虎
             * vehicle : 赵虎
             * state : 2
             */

            private String id;
            private String number;
            private String Product_type;
            private String product;
            private String customer;
            private String phone;
            private String address;
            private String esttime_delivery;
            private String esttime_install;
            private String sectime_delivery;
            private String sectime_install;
            private String cfmtime_delivery;
            private String cfmtime_install;
            private String staff;
            private String vehicle;
            private String state;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getNumber() {
                return number;
            }

            public void setNumber(String number) {
                this.number = number;
            }

            public String getProduct_type() {
                return Product_type;
            }

            public void setProduct_type(String Product_type) {
                this.Product_type = Product_type;
            }

            public String getProduct() {
                return product;
            }

            public void setProduct(String product) {
                this.product = product;
            }

            public String getCustomer() {
                return customer;
            }

            public void setCustomer(String customer) {
                this.customer = customer;
            }

            public String getPhone() {
                return phone;
            }

            public void setPhone(String phone) {
                this.phone = phone;
            }

            public String getAddress() {
                return address;
            }

            public void setAddress(String address) {
                this.address = address;
            }

            public String getEsttime_delivery() {
                return esttime_delivery;
            }

            public void setEsttime_delivery(String esttime_delivery) {
                this.esttime_delivery = esttime_delivery;
            }

            public String getEsttime_install() {
                return esttime_install;
            }

            public void setEsttime_install(String esttime_install) {
                this.esttime_install = esttime_install;
            }

            public String getSectime_delivery() {
                return sectime_delivery;
            }

            public void setSectime_delivery(String sectime_delivery) {
                this.sectime_delivery = sectime_delivery;
            }

            public String getSectime_install() {
                return sectime_install;
            }

            public void setSectime_install(String sectime_install) {
                this.sectime_install = sectime_install;
            }

            public String getCfmtime_delivery() {
                return cfmtime_delivery;
            }

            public void setCfmtime_delivery(String cfmtime_delivery) {
                this.cfmtime_delivery = cfmtime_delivery;
            }

            public String getCfmtime_install() {
                return cfmtime_install;
            }

            public void setCfmtime_install(String cfmtime_install) {
                this.cfmtime_install = cfmtime_install;
            }

            public String getStaff() {
                return staff;
            }

            public void setStaff(String staff) {
                this.staff = staff;
            }

            public String getVehicle() {
                return vehicle;
            }

            public void setVehicle(String vehicle) {
                this.vehicle = vehicle;
            }

            public String getState() {
                return state;
            }

            public void setState(String state) {
                this.state = state;
            }
        }
    }
}
