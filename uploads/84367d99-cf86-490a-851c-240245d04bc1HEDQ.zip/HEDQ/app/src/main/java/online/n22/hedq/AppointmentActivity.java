package online.n22.hedq;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.codbking.widget.DatePickDialog;
import com.codbking.widget.OnSureLisener;
import com.codbking.widget.bean.DateType;
import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.Date;

import online.n22.hedq.bean.RespBean;
import online.n22.hedq.bean.WorkBean;
import online.n22.hedq.utils.Api;
import online.n22.hedq.utils.DialogHelp;

public class AppointmentActivity extends BaseActivity {
    private TextView tv_title;
    private ImageView iv_back;
    private TextView et_appointment;

    private Button btn_appointment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText("协定安装时间");
        iv_back = (ImageView) findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppointmentActivity.this.finish();
            }
        });
        et_appointment = (TextView) findViewById(R.id.et_appointment);
        et_appointment.setInputType(InputType.TYPE_NULL);
        et_appointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showYMD();
            }
        });
        btn_appointment = (Button) findViewById(R.id.btn_appointment);
        btn_appointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String date = et_appointment.getText().toString().trim();
                if (!TextUtils.isEmpty(date)) {
                    DialogHelp.getConfirmDialog(AppointmentActivity.this, "您选择的预约时间是" + date + "，请确认！", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            WorkBean.DataBean.Table1Bean table1Bean1 = (WorkBean.DataBean.Table1Bean) getIntent().getSerializableExtra("key_item");
                            Api.getPhtime(AppointmentActivity.this, table1Bean1.getId(), date, new Api.OnResponseListener() {
                                @Override
                                public void onResponse(String json) {
                                    RespBean resp = new Gson().fromJson(json, RespBean.class);
                                    if ("1".equals(resp.getData().getDs())) {
                                        DialogHelp.getMessageDialog(AppointmentActivity.this, resp.getData().getValue()).show();
                                    }
                                }
                            });
                        }
                    }).show();
                } else {
                    DialogHelp.getMessageDialog(AppointmentActivity.this, "请点击选择预约日期！").show();
                }
            }
        });
    }

    public void showYMD() {
        DatePickDialog dialog = new DatePickDialog(AppointmentActivity.this);
        //设置上下年分限制
        dialog.setYearLimt(100);
        //设置标题
        dialog.setTitle("选择时间");
        //设置类型
        dialog.setType(DateType.TYPE_YMD);
        //设置消息体的显示格式，日期格式
        dialog.setMessageFormat("yyyy-MM-dd");
        //设置选择回调
        dialog.setOnChangeLisener(null);
        //设置点击确定按钮回调
        dialog.setOnSureLisener(new OnSureLisener() {
            @Override
            public void onSure(Date date) {
                SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
                et_appointment.setText(f.format(date));
            }
        });
        dialog.show();
    }

//    public void onYearMonthDayTimePicker(View view) {
//        DateTimePicker picker = new DateTimePicker(this, DateTimePicker.HOUR_24);
//        Calendar cal = Calendar.getInstance();
//        picker.setDateRangeStart(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE));
//        picker.setDateRangeEnd(2099, 12, 31);
//        picker.setTimeRangeStart(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
//        picker.setTimeRangeEnd(23, 59);
//        picker.setTopLineColor(0x99FF0000);
//        picker.setLabelTextColor(0xFFFF0000);
//        picker.setDividerColor(0xFFFF0000);
//        picker.setOnDateTimePickListener(new DateTimePicker.OnYearMonthDayTimePickListener() {
//            @Override
//            public void onDateTimePicked(String year, String month, String day, String hour, String minute) {
//                et_appointment.setText(year + "-" + month + "-" + day + " " + hour + ":" + minute);
//            }
//        });
//        picker.show();
//    }

}
