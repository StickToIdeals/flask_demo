package online.n22.hedq;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.inputmethod.InputMethodManager;

public class BaseActivity extends AppCompatActivity {
    @Override
    public void finish() {
        super.finish();
        // 设置activity退出动画
        BaseActivity.this.overridePendingTransition(R.anim.activity_tab_pay_close, R.anim.activity_tab_pay_close);
    }

}