package online.n22.hedq;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import online.n22.hedq.bean.UserBean;
import online.n22.hedq.utils.Api;
import online.n22.hedq.utils.DialogHelp;
import online.n22.hedq.utils.XConfigUtil;

public class EditPassActivity extends BaseActivity {
    private TextView tv_title;
    private ImageView iv_back;

    private Button btn_modify;

    private EditText et_old_pass;
    private EditText et_new_pass;

    private String old_pass;
    private String new_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_pass);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText("修改密码");
        iv_back = (ImageView) findViewById(R.id.iv_back);
        btn_modify = (Button) findViewById(R.id.btn_modify);
        et_old_pass = (EditText) findViewById(R.id.et_old_pass);
        et_new_pass = (EditText) findViewById(R.id.et_new_pass);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditPassActivity.this.finish();
            }
        });
        btn_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                old_pass = et_old_pass.getText().toString().trim();
                new_pass = et_new_pass.getText().toString().trim();
                if (!TextUtils.isEmpty(old_pass) && !TextUtils.isEmpty(new_pass)) {
                    String json = XConfigUtil.getInstance(EditPassActivity.this).getString("LOGIN_INFO");
                    if(!TextUtils.isEmpty(json)){
                        UserBean userBean = new Gson().fromJson(json, UserBean.class);
                        String id = userBean.getData().getTable1().get(0).getId();
                        Api.getPhres(EditPassActivity.this, id, old_pass, new_pass, new Api.OnResponseListener() {
                            @Override
                            public void onResponse(String json) {
                                DialogHelp.getMessageDialog(EditPassActivity.this, json).show();
                            }
                        });
                    }else{
                        DialogHelp.getMessageDialog(EditPassActivity.this,"程序未知错误，请重新登陆！").show();
                    }

                } else {
                    DialogHelp.getMessageDialog(EditPassActivity.this, "请输入原密码/新密码!").show();
                }
            }
        });
    }
}
